<?php
$db = mysqli_connect("localhost:3306", "root", "", "test");
if (!$db) {
  die("Connection failed: " . mysqli_connect_error());
}
?>