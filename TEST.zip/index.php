<?php
session_start();
if(isset($_SESSION["userName"]) && isset($_SESSION["phone"])){
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ChatRoom</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <h1>ChatRoom</h1>
  <div class="chat">
    <h2>Welcome <span><?= $_SESSION["userName"]?></span></h2>
    <div class="msg">
      


    </div>
    <div class="input_msg">
      <input type="text" placeholder="Write msg Here" id="input_msg">
      <button onclick="update()">Send</button>
    </div>
  </div>
</body>
<script>
// Read Messages from the DataBase 
let msgdiv = document.querySelector(".msg");
let lastMessageId = 0; // Variable to store the ID of the last fetched message

function fetchMessages() {
  fetch(`readMsg.php?lastMessageId=${lastMessageId}`).then(
    r => {
      if (r.ok) {
        return r.text();
      } else {
        console.error("Failed to fetch messages:", r.status, r.statusText);
      }
    }
  ).then(
    d => {
      msgdiv.innerHTML = d;
      msgdiv.scrollTop = msgdiv.scrollHeight - msgdiv.clientHeight;
    }
  ).catch(error => {
    console.error("Error reading messages:", error);
  });
}

fetchMessages(); // Fetch messages when the page loads

// Check for new messages every 500 milliseconds
setInterval(fetchMessages, 500);

// ADD Messages to the DataBase 
function update() {
  let msg = document.getElementById('input_msg').value;
  document.getElementById('input_msg').value = "";
  fetch('addMsg.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'msg=' + encodeURIComponent(msg), // Encode the message
  }).then(
    r => {
      if (r.ok) {
        return r.text();
      } else {
        console.error("Failed to add message:", r.status, r.statusText);
      }
    }
  ).then(
    d => {
      console.log("Server Response:", d);
      // Assuming you want to refresh the messages after sending a new one
      fetchMessages(); // Refresh messages
    }
  ).catch(error => {
    console.error("Error adding message:", error);
  });
}
</script>

</html>

<?php
}else{
  header("location: login.php");
}
?>
