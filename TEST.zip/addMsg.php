<?php
session_start();
include "db.php";

// Check if user is logged in
if (!isset($_SESSION["userName"]) || !isset($_SESSION["phone"])) {
    die("You are not logged in.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userName = $_SESSION["userName"]; // Get the username from the session
    $msg = trim($_POST["msg"]);

    if (!empty($msg)) {
        $q = "INSERT INTO `msg` (`user_name`, `msg`) VALUES ('$userName', '$msg')";
        if (mysqli_query($db, $q)) {
            echo "Message sent successfully!";
        } else {
            echo "Error: " . mysqli_error($db);
        }
    } else {
        echo "Message cannot be empty!";
    }
} else {
    echo "Invalid request!";
}
?>
