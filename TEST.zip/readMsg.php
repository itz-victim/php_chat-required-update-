<?php
session_start();
include "db.php";

// Check if user is logged in
if (!isset($_SESSION["userName"]) || !isset($_SESSION["phone"])) {
    die("You are not logged in.");
}

$q = "SELECT * FROM `msg` ORDER BY id DESC"; // Query to select messages
if ($rq = mysqli_query($db, $q)) {
    if (mysqli_num_rows($rq) > 0) {
        while ($data = mysqli_fetch_assoc($rq)) {
            $sender = isset($data["user_name"]) ? $data["user_name"] : "Unknown"; // Check if user_name key exists
            ?>
            <p <?php if ($sender == $_SESSION["userName"]) echo 'class="sender"'; ?>>
                <span><?php echo $sender; ?></span>
                <?php echo $data["msg"]; ?>
            </p>
            <?php
        }
    } else {
        echo "<h3> Chat is empty at this moment!!</h3>";
    }
} else {
    echo "<h3> Error fetching messages from the database!!</h3>";
}
?>
