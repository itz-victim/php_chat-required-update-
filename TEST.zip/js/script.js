// ADD Messages to the DataBase 
window.onkeydown = (e) => {
  if (e.key == "Enter") {
    update();
  }
};

function update() {
  let msg = document.getElementById('input_msg').value;
  document.getElementById('input_msg').value = "";
  fetch('addMsg.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'msg=' + encodeURIComponent(msg), // Encode the message
  }).then(
    r => {
      if (r.ok) {
        return r.text();
      } else {
        console.error("Failed to add message:", r.status, r.statusText);
      }
    }
  ).then(
    d => {
      console.log("Server Response:", d);
      // Assuming you want to refresh the messages after sending a new one
      fetchMessages(); // Refresh messages
    }
  ).catch(error => {
    console.error("Error adding message:", error);
  });
}
